/*
la paleta de colores y la disposición de elementos inspirados en diversos shots de http://dribbble.com/